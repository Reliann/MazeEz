from socket import*
from json import dumps, loads
from threading import Thread, Lock
from queue import Queue


REQUEST_GAME = "019"
SERVER_ADDRESS = ('127.0.0.1', 5030)
REFUSE_TCP_CONNECTION = "002"
RESPOND_CONNECTION = "001"
REQUEST_LOGIN = "003"
RESPOND_LOGIN = "004"
REQUEST_SIGUP = "006"
RESPOND_SIGNUP = "005"
GAMEDATA = '020'
LOGOUT = "007"
ADD_FRIEND = "008"
REQUEST_FRIEND_LIST = "010"
RESPOND_FRIEND_LIST = "011"
RESPOND_FRIEND_REQUEST = "012"
INVITE_FRIEND_TO_GAME = "013"
KICK_FROM_PARTY = '014'


class TcpClient(Thread):
    def __init__(self):
        super().__init__()
        self.daemon = True  # close after ur done :)
        self.TCPsock = socket(AF_INET, SOCK_STREAM)
        self.is_connected = True
        self.identifier = None
        self.ui_queue = Queue()
        self.game_updates = Queue()
        self.TCPsock.connect(SERVER_ADDRESS)
        self.user = None

    def run(self):

        while self.is_connected:
                data_length = self.TCPsock.recv(5)
                try:
                    data_length = int(data_length)
                except ValueError:
                    continue

                data = loads(self.TCPsock.recv(data_length).decode())

                try:
                    typ = data['type']
                except KeyError:
                    continue

                if typ == GAMEDATA:
                    self.game_updates.put(data['payload'])
                    continue

                if typ == RESPOND_CONNECTION:
                    try:
                        self.identifier = data['payload']['identifier']
                        continue

                    except KeyError:
                        continue

                if typ == REFUSE_TCP_CONNECTION:
                    self.TCPsock.close()
                    self.ui_queue.put(data['type'], data['payload'])
                    break

                if typ == RESPOND_LOGIN or typ == RESPOND_SIGNUP:
                    try:    # if there is no error key in 'payload', it's the user.
                        data['payload']['error']
                    except KeyError:
                        self.user = data['payload']

                self.ui_queue.put((data['type'], data['payload']))

    def login(self, username, password):
        self.send_server(REQUEST_LOGIN, {
                                         'username': username, 'password': password
                                        })

    def signup(self, username, password, email):
        self.send_server(REQUEST_SIGUP,
                         {
                              'username': username,
                              'password': password,
                              'email': email
                         })

    def request_game(self):
        self.send_server(REQUEST_GAME, None)

    def send_server(self, t, payload):
        m = {'type': t, 'payload': payload, 'identifier': self.identifier}
        m = dumps(m)
        m_length = str(len(m))
        while len(m_length) < 5:
            m_length = "0" + m_length
        self.TCPsock.send((m_length + m).encode())

    def send_event(self, data):
        self.send_server(GAMEDATA, data)

    def logout(self):
        if self.user:
            self.send_server(LOGOUT, "")
            self.user = None

    def add_friend(self, friend_name):
        if self.user and self.user['username'] != friend_name:
            self.send_server(ADD_FRIEND, friend_name)
        else:
            self.ui_queue.put(("Client Error", {'message': "you can't add yourself"}))

    def request_friend_list(self):
        if self.user:
            self.send_server(REQUEST_FRIEND_LIST, "")
        else:
            self.ui_queue.put(("Client Error", {'message': "no user authorized"}))

    def disconnect(self):   # ToDo: properly close connection
        self.is_connected = False
        # self.TCPsock.close()

    def reply_friend_request(self, friend_name, response):
        if self.user:
            self.send_server(RESPOND_FRIEND_REQUEST,{'friend_name':friend_name,'response':response})

    def invitefriend(self, friend_name):
        if self.user:
            self.send_server(INVITE_FRIEND_TO_GAME, friend_name)

    def kick_from_party(self, friend_name):
        if self.user:
            self.send_server(KICK_FROM_PARTY, friend_name)
