import pygame as pygame
import gui
import client
import ctypes
from MazeEz import game


user32 = ctypes.windll.user32
LOGO = pygame.image.load(r"resources\coollogo_com-9162951.png")
BACKGROUND = pygame.image.load(r"resources\sprite_northWindShrineBG.png")
WIDTH_SCALE = user32.GetSystemMetrics(0)//1280
HEIGHT_SCALE = user32.GetSystemMetrics(1)//720

def on_quit():  # temporary
    pygame.quit()
    quit()


def intro_menu(screen):
    # Drawing buttons

    screen.blit(BACKGROUND,(0, 0))
    screen.blit(LOGO, (135, 60))

    buttons = [gui.Button(screen, text="Log In", x=205,y=180, width=100,height=40),
               gui.Button(screen, text="Sign Up", x=205, y=240, width=100, height=40)]

    for button in buttons:
        button.draw()
    

    
    pygame.display.flip()

    # Running intro menu loop
    running = True
    next_do = ''
    fps_c = pygame.time.Clock()

    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_buttons = pygame.mouse.get_pressed()
        click = mouse_buttons[0]
        # event handling, gets all event from the eventqueue

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                on_quit()
                running = False

        for button in buttons:
            if button.isover(mouse_pos) and click:
                    next_do = button.name      # default name is text
                    running = False

        pygame.display.flip()
        fps_c.tick(30)

    return next_do


def signup_window(screen):
    screen.blit(BACKGROUND, (0, 0))
    screen.blit(LOGO, (135, 60))
    buttons = [gui.Button(screen, text="Back", x=20, y=20, width=50, height=30),
               gui.Button(screen, text="Sign Up", x=205, y=340, width=100, height=40)]
    textboxs = [gui.InputBox(screen, x=215,y=180,width=150,height=30,name='username'),
                gui.InputBox(screen, x=215, y=220, width=150, height=30, name='email'),
                gui.InputBox(screen, x=215, y=260, width=150, height=30, name='password')]
    labels = [gui.Label(screen, x=157, y=195, width=0, height=0, text="Username:"),  # a nice trick to make transparent
              gui.Label(screen, x=175, y=235, width=0, height=0, text="Email:"),
              gui.Label(screen, x=160, y=275, width=0, height=0, text="Password:")]
    for label in labels + buttons + textboxs:    # this python thing is amazing!
        label.draw()

    pygame.display.flip()
    running = True
    next_do = ''
    fps_c = pygame.time.Clock()

    while running:

        # event handling, gets all event from the eventqueue
        mouse_buttons = pygame.mouse.get_pressed()
        mouse_pos = pygame.mouse.get_pos()
        click = mouse_buttons[0]
        char = ''
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                on_quit()
                running = False
            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_BACKSPACE:
                    char = 'del'
                else:
                    char = event.unicode

        for button in buttons:
            if button.isover(mouse_pos) and click:
                if button.name == 'Sign Up':  # ToDo: check requirements better
                    allowed = True
                    for textbox in textboxs:
                        if not textbox.text:
                            allowed = False
                    if not allowed:
                        continue
                next_do = button.name  # default name is text
                running = False

        for textbox in textboxs:
            if textbox.isover(mouse_pos):
                if click:
                    textbox.selected(True)
            elif click:
                textbox.selected(False)
            if textbox.isselected:
                if char == 'del':
                    textbox.inchar()
                elif char:
                    textbox.inchar(char)



        pygame.display.flip()
        fps_c.tick(30)

    if next_do == 'Back':
        return 'intro', None
    if next_do == 'Sign Up':
        user = {}
        for textbox in textboxs:
            user[textbox.name]=textbox.text
        return 'signup', user


def login_window(screen):
    screen.blit(BACKGROUND, (0, 0))
    screen.blit(LOGO, (135, 60))
    buttons = [gui.Button(screen, text="Back", x=20, y=20, width=50, height=30),
               gui.Button(screen, text="Log In", x=205, y=340, width=100, height=40)]
    textboxs = [gui.InputBox(screen, x=215, y=180, width=150, height=30, name='username'),
                gui.InputBox(screen, x=215, y=220, width=150, height=30, name='password')]
    labels = [gui.Label(screen, x=166, y=195, width=0, height=0, text="Username:"),  # a nice trick to make transparent
              gui.Label(screen, x=169, y=235, width=0, height=0, text="Password:")]

    for label in labels + buttons + textboxs:  # this python thing is amazing!
        label.draw()

    pygame.display.flip()
    running = True
    next_do = ''
    fps_c = pygame.time.Clock()

    while running:

        # event handling, gets all event from the eventqueue
        mouse_buttons = pygame.mouse.get_pressed()
        mouse_pos = pygame.mouse.get_pos()
        click = mouse_buttons[0]
        char = ''
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False
                on_quit()
            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_BACKSPACE:
                    char = 'del'
                else:
                    char = event.unicode

        for button in buttons:
            if button.isover(mouse_pos) and click:
                if button.name == 'Log In':  # ToDo: check requirements better
                    allowed = True
                    for textbox in textboxs:
                        if not textbox.text:
                            allowed = False
                    if not allowed:
                        MessageBox = ctypes.windll.user32.MessageBoxW
                        MessageBox(None, 'Please fill in all details, they are necessary.', 'Error', 0)
                        continue
                next_do = button.name  # default name is text
                running = False

        for textbox in textboxs:
            if textbox.isover(mouse_pos):
                if click:
                    textbox.selected(True)
            elif click:
                textbox.selected(False)
            if textbox.isselected:
                if char == 'del':
                    textbox.inchar()
                elif char:
                    textbox.inchar(char)

        pygame.display.flip()
        fps_c.tick(30)

    if next_do == 'Back':
        return 'intro', None
    if next_do == 'Log In':
        user = {}
        for textbox in textboxs:
            user[textbox.name] = textbox.text
        return 'login', user


def loadvirefy(screen, user, action, myclient):
    screen.blit(BACKGROUND, (0, 0))
    screen.blit(LOGO, (135, 60))

    if action == 'signup':
        myclient.signup(user['username'], user['password'], user['email'])
    if action == 'login':
        myclient.login(user['username'], user['password'])

    running = True
    data = None
    fps_c = pygame.time.Clock()
    while running:
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

        if myclient.ui_queue.empty():

            typ, data = myclient.ui_queue.get()
            running = False

        fps_c.tick(30)

    try:
        error_msg = data['error']
        MessageBox = ctypes.windll.user32.MessageBoxW
        MessageBox(None, error_msg, 'Error', 0)
    except KeyError:
        return data

    return None


def startup_display(screen, myclient):
    user_virefied = False
    action = intro_menu(screen)
    user = None
    while not user_virefied:

        if action == 'intro':
            action = intro_menu(screen)
        if action == 'Sign Up':
            action, user = signup_window(screen)
            continue
        if action == 'Log In':
            action, user = login_window(screen)
            continue
        if action == 'login' or action == 'signup':
            user = loadvirefy(screen, user, action, myclient)
            if user:
                user_virefied = True
            elif action == 'login':
                action = 'Log In'
                user = None
            else:
                action = 'Sign Up'
                user = None
    return user


def main_game_manue(screen, myclient):
    screen.blit(BACKGROUND, (0, 0))
    screen.blit(LOGO, (135*WIDTH_SCALE, 60*HEIGHT_SCALE))

    buttons = [gui.Button(screen, text="Play", x=205, y=180, width=115, height=40),
               gui.Button(screen, text="Invite Friend", x=205, y=230, width=115, height=40),
               gui.Button(screen, text="Add Friend", x=205, y=280, width=115, height=40),
               gui.Button(screen, text="Log Out", x=20, y=10, width=100, height=40)]
    labels = [gui.Label(screen, x=20, y=400, width=120, height=45, text=("Username: " + myclient.user['username']),
                        color=(145, 187, 255))]

    for label in buttons + labels:
        label.draw()

    pygame.display.flip()
    mygame = game(myclient, screen)
    # Running intro menu loop
    running = True
    next_do = ''
    fps_c = pygame.time.Clock()

    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_buttons = pygame.mouse.get_pressed()
        click = mouse_buttons[0]
        # event handling, gets all event from the eventqueue

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                on_quit()
                running = False

        for button in buttons:
            if button.isover(mouse_pos) and click:
                next_do = button.name  # default name is text
                running = False

        if next_do == 'Play':
            mygame.playgame()
            next_do = None

        pygame.display.flip()
        fps_c.tick(30)

    return next_do


if __name__ == '__main__':
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((500* WIDTH_SCALE, 500*HEIGHT_SCALE))
    logo = pygame.image.load(r"resources\kitty\frame_0.png").convert_alpha()
    logo = pygame.transform.scale(logo,(32, 32))
    pygame.display.set_icon(logo)
    pygame.display.set_caption(r"MazeEz")
    pygame.key.set_repeat(50, 50)  # set repeat for menues.
    myclient = client.TcpClient()
    myclient.start()
    user = startup_display(screen, myclient)
    next_do = ""
    while next_do != 'quit':
        next_do = main_game_manue(screen, myclient)
        if next_do == 'Log Out':
            user = startup_display(screen, myclient)

    myclient.disconnect()
    on_quit()

