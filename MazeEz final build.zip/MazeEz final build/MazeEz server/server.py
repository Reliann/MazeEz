from socket import*
from json import dumps, loads
import uuid
from threading import Thread, Lock
from queue import *
import DataBase as db
import select
import Rooms


MAX_CLIENTS = 4

TCP_SERVER_ADDRESS = ('127.0.0.1', 5030)

RESPOND_CONNECTION = "001"
REFUSE_TCP_CONNECTION = "002"
REQUEST_LOGIN = "003"
RESPOND_LOGIN = "004"
REQUEST_SIGUP = "006"
RESPOND_SIGNUP = "005"
GAMEDATA = "020"
REQUEST_GAME = "019"
LOGOUT = "007"
ADD_FRIEND = "008"
RESPOND_ADD_FRIEND = "009"
REQUEST_FRIEND_LIST = "010"
RESPOND_FRIEND_LIST = "011"
INVITE_FRIEND_TO_PARTY = "012"
RESPOND_FRIEND_REQUEST = "013"
KICK_FROM_PARTY = '014'


class TcpServer(Thread):
    def __init__(self, addr, lock, rooms_manager):
        super().__init__()
        self.daemon = True
        self.address = addr
        self.lock = lock
        self.rooms_manager = rooms_manager
        self.is_running = True
        self.server = socket(AF_INET, SOCK_STREAM)
        self.online_clients = {}
        self.online = 0

    def run(self):
        self.server.bind(self.address)
        self.server.setblocking(False)
        self.server.settimeout(5)
        self.server.listen(3)
        inputs = [self.server]
        outputs = []
        data_queues = {}

        while inputs and self.is_running:
            """ 
            handles one request at a cycle, clients are not allowed to send big data (max 99999 bits)
            because the only data they should send is bound to be under that limit.
            """
            readable, writable, exceptional = select.select(
                inputs, outputs, inputs)
            for s in readable:

                if s is self.server:
                    connection, client_address = s.accept()
                    if self.online == MAX_CLIENTS:
                        self.send_refuse(connection, "server is full.")
                    else:
                        self.online += 1
                        connection.setblocking(0)
                        inputs.append(connection)
                        self.online_clients[connection] = ClientHandler(connection, client_address,
                                                                           str(uuid.uuid4()), self.rooms_manager)
                        data_queues[connection] = Queue()
                        print("connected from: " + str(client_address))
                else:
                    try:
                        message_length = s.recv(5)
                    except ConnectionResetError:
                        inputs.remove(s)
                        if s in outputs:
                            outputs.remove(s)
                        s.close()
                        print('disconnected from: ' + str(self.online_clients[s].address))
                        del data_queues[s]
                        del self.online_clients[s]
                        continue
                    try:
                        message_length = int(message_length)
                    except ValueError:
                        data = ""
                    else:
                        data = loads(s.recv(message_length).decode())

                    if data:
                        data_queues[s].put(data)
                        if s not in outputs:
                            outputs.append(s)
                    else:
                        if s in outputs:
                            outputs.remove(s)
                        inputs.remove(s)
                        s.close()
                        print('disconnected from: ' + self.online_clients[s].address)
                        del data_queues[s]
                        del self.online_clients[s]

            for s in writable:
                try:
                    new_data = data_queues[s].get_nowait()
                except Empty:
                    outputs.remove(s)
                else:
                    self.online_clients[s].handle_new_data(new_data)

            for s in exceptional:
                inputs.remove(s)
                if s in outputs:
                    outputs.remove(s)
                s.close()
                del data_queues[s]
                del self.online_clients[s]

    def server_shutdown(self):
        self.is_running = False
        # self.online_clients.clear()   # a way around this?

    def send_refuse(self, conn, err):
        m = dumps({'type': REFUSE_TCP_CONNECTION, 'payload': err})
        m_length = str(len(m))
        while len(m_length) < 5:
            m_length = "0" + m_length
        conn.send((m_length + m).encode())
        conn.close()


class ClientHandler(object):
    online_users = []
    def __init__(self, connection, address, identifier, rm):
        self.sock = connection
        self.address = address
        self.identifier = identifier
        self.rooms_manager = rm
        self.send_TCP(RESPOND_CONNECTION,
                      {"identifier": self.identifier})
        self.user = None
        self.room_id = None
        self.mate = None

    def handle_new_data(self, data):
        """
        handles client's requests
        """

        try:
            typ = data['type']
        except KeyError:
            return

        if typ == REQUEST_LOGIN:
            try:
                self.login_request(data['payload'])
            except KeyError:
                return

        if typ == REQUEST_SIGUP:
            try:
                self.signup_request(data['payload'])
            except KeyError:
                return

        if typ == REQUEST_GAME:
            try:
                self.game_request()
            except KeyError:
                return

        if typ == GAMEDATA:
            try:
                self.rooms_manager.put_event(data['payload'], self.room_id)
            except KeyError:
                return

        if typ == LOGOUT:
            self.logout()
            return

        if typ == ADD_FRIEND:
            try:
                self.add_friend(data['payload'])
            except KeyError:
                return
        if typ == REQUEST_FRIEND_LIST:
            try:
                self.friend_list_request()
            except KeyError:
                return

        if typ == RESPOND_FRIEND_REQUEST:
            try:
                self.respond_friend(data['payload'])
            except KeyError:
                return

    def request_invite(self, data):
        if self.user:
           for user in ClientHandler.online_users:
               if user[0] == data['friend_name']:
                   user[1].send_invite(self.user['username'])

    def send_invite(self, friend):
        self.send_TCP("tba",{'username': friend})

    def respond_invite(self, data):
        for user in ClientHandler.online_users:
            if user[0] == data['friend_name']:
                if  user[1].agreejoin(self):
                    self.mate = user[1]

    def agreejoin(self, friend):
        self.mate = friend
        return True

    def respond_friend(self,data):
        if self.user:
            db.set_friend(self.user,data['friend_name'],data['response'])
        if data['response']:
            self.send_TCP(RESPOND_FRIEND_REQUEST, {'message':data['friend_name']+" was successfully added to your friend list"})
        else:
            self.send_TCP(RESPOND_FRIEND_REQUEST,
                          {'message': data['friend_name'] + " was declined"})

    def game_request(self):
        """should seperate from any game types"""
        print("got a game request")
        if self.user:
            error = self.rooms_manager.queue_player(self)
            if error:
                self.send_TCP(GAMEDATA, {'error': error})

    def friend_list_request(self):
        if self.user:
            friend_list = db.get_friends_list(self.user)
            self.send_TCP(RESPOND_FRIEND_LIST, friend_list)
        else:
            self.send_TCP(RESPOND_FRIEND_LIST, {'error': 'you are not authorized'})

    def add_friend(self, friend_name):
        if self.user and self.user['username'] != friend_name:
            data = db.add_friend(self.user, friend_name)
            self.send_TCP(RESPOND_ADD_FRIEND, {'message': data})
        else:
            self.send_TCP(RESPOND_ADD_FRIEND, {'message': "you can't add yourself"})

    def login_request(self, user):

        auth = db.login_user_via_username(user["username"], user["password"])
        if not 'error' in auth.keys():
            self.user = auth
            ClientHandler.online_users.append((self.user['username'], self))
            self.send_TCP(RESPOND_LOGIN, self.user)
        else:
            self.send_TCP(RESPOND_LOGIN, auth)

    def signup_request(self, new_user):
        auth = db.signup_user(new_user["username"], new_user["password"], new_user['email'])
        if auth is not None:
            self.user = auth
            ClientHandler.online_users.append((self.user['username'], self))
            self.send_TCP(RESPOND_SIGNUP, self.user)
        else:
            self.send_TCP(RESPOND_SIGNUP, auth)

    def send_gamedata(self, maze):
        self.send_TCP(GAMEDATA, maze)

    def send_TCP(self, t, payload):
        m = {'type': t, 'payload': payload}
        m = dumps(m)
        m_length = str(len(m))
        while len(m_length) < 5:
            m_length = "0" + m_length
        self.sock.send((m_length + m).encode())

    def logout(self):
        if self.user:
            ClientHandler.online_users.remove((self.user['username'], self))
            self.user = None

    def leavequeue(self):
        pass

    def leave_party(self, status):
        pass

    def __del__(self):
        self.sock.close()
        if self.user:
            self.logout()


def main_loop():
    db.initialize_database()
    lock = Lock()
    rm = Rooms.RoomsManager(lock)
    tcp_server = TcpServer(TCP_SERVER_ADDRESS, lock, rm)
    tcp_server.start()

    print("type quit to shutdown server\n"
          ,"view to see online users")
    while True:
        command = input()
        if command == "quit":
            tcp_server.server_shutdown()
            break
        if command == "view":
            for user in ClientHandler.online_users:
                print(user[0])


if __name__ == '__main__':
    main_loop()
