import ctypes

if __name__ == '__main__':
    user32 = ctypes.windll.user32
    print(user32.GetSystemMetrics(0), user32.GetSystemMetrics(1))